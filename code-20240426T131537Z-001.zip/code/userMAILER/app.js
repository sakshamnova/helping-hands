const express = require('express');
const bodyParser = require('body-parser');
const nodemailer = require('nodemailer');

const app = express();
const port = 3000;
app.use(express.static("style"));
app.use(bodyParser.urlencoded({extended: true}));

app.get("/",function(req,res){
    res.sendFile(__dirname + "/form1.html")
    console.log(__dirname);
});

app.post("/",function(req,res){
    const comm= req.body.description;
    const na=req.body.name;
    var transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: 'shrutitanya49070@gmail.com',
            pass: 'hffg kgip ygpa lavf'
        }
    })
    var mailOptions ={
        from: 'shrutitanya49070@gmail.com',
        to: req.body.email,
        cc: 'shrutitanya49070@gmail.com',
        subject:'Hey '+na,
        text: 'Request Received: '+ comm
    };

    transporter.sendMail(mailOptions, function(error, info){
        if(error){
            console.log(error);
        }
        else{
            //res.send("mail submitted")
            res.redirect('/');
            console.log("email sent"+ info.response);
        }
    })
});


app.listen(3000,function(){
    console.log("server started at 3000");
})
